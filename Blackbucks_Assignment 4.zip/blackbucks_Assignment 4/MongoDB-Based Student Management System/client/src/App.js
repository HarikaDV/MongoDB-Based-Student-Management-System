import Path from "./routes/Path";

function App() {
  return (
    <div className="App">
      <Path />
    </div>
  );
}

export default App;
