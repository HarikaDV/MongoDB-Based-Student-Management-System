import React from "react";
import EditStudent from "../../components/EditStudent/EditStudent";

const Edit = () => {
  return (
    <>
      <EditStudent />
    </>
  );
};

export default Edit;
