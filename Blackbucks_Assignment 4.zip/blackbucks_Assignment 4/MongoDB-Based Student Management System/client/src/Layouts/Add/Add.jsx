import React from "react";
import AddStudent from "../../components/AddStudent/AddStudent";

const Add = () => {
  return (
    <>
      <AddStudent />
    </>
  );
};

export default Add;
